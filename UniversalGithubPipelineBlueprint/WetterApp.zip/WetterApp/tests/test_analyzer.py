import pytest
from src.core.analyzer import calculate_statistics


def test_calculate_statistics_with_valid_data():
    """Verifies statistical evaluation routines using a standard
    array of float entries."""
    data = [10.0, 20.0, 30.0, 40.0, 50.0]
    results = calculate_statistics(data)

    assert results["count"] == 5
    assert results["mean"] == 30.0
    assert results["variance"] == 200.0
    assert results["std_dev"] == 14.1421
    # sqrt(200) mathematically rounded to 4 decimal indices


def test_calculate_statistics_empty_list():
    """Guarantees that empty collections are handled safely without
    triggering an active ZeroDivisionError."""
    results = calculate_statistics([])

    assert results["count"] == 0
    assert results["mean"] == 0.0
    assert results["variance"] == 0.0
    assert results["std_dev"] == 0.0


def test_calculate_statistics_single_element():
    """Asserts boundary evaluation loops when handling a single
    dataset entity (variance must equal 0)."""
    results = calculate_statistics([42.0])

    assert results["count"] == 1
    assert results["mean"] == 42.0
    assert results["variance"] == 0.0
    assert results["std_dev"] == 0.0


@pytest.mark.parametrize("data, expected_mean", [
    ([1.5, 2.5, 3.5], 2.5),
    ([-10.0, 0.0, 10.0], 0.0),
    ([100.0, 200.0], 150.0)
])
def test_calculate_statistics_parameterized(data, expected_mean):
    """Leverages dataset parameterization to test
    diverse mathematical matrices at scale."""
    results = calculate_statistics(data)
    assert results["mean"] == expected_mean
