import math
from typing import Dict, List, Union


def calculate_statistics(data_points: List[float]) -> Dict[str, Union[float, int]]:
    """
    Computes statistical indicators for a
    one-dimensional array of numeric
    entries.
    This pure functional logic is isolated
    and has zero dependencies on graphical
    runtimes.
    """
    if not data_points:
        return {
            "count": 0,
            "mean": 0.0,
            "variance": 0.0,
            "std_dev": 0.0
        }

    total_sum = sum(data_points)
    count = len(data_points)
    mean = total_sum / count

    # Compute population variance
    variance = sum((x - mean) ** 2 for x in data_points) / count
    std_dev = math.sqrt(variance)

    return {
        "count": count,
        "mean": round(mean, 4),
        "variance": round(variance, 4),
        "std_dev": round(std_dev, 4)
    }
