import tkinter as tk
from src.gui.window import DataCruncherApp


def main() -> None:
    """Instantiates the root GUI environment loop."""
    root = tk.Tk()
    DataCruncherApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
