import tkinter as tk
from tkinter import messagebox
from src.core.analyzer import calculate_statistics


class DataCruncherApp:
    """
    Orchestrates the primary window framing and layout ecosystem.
    Decouples visual display components from mathematical operations.
    """
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("DataCruncher Professional")
        self.root.geometry("400x300")

        # Initialize visual layout anchors
        self.label = tk.Label(root, text="Enter numbers (comma-separated):")
        self.label.pack(pady=10)

        self.entry = tk.Entry(root, width=40)
        self.entry.pack(pady=5)

        self.calc_button = tk.Button(root, text="Compute Statistics",
                                     command=self.process_input)
        self.calc_button.pack(pady=10)

        self.result_text = tk.Label(root, text="", font=("Courier", 10))
        self.result_text.pack(pady=20)

    def process_input(self) -> None:
        """Parses UI raw entries, triggers the decoupled calculation,
        and updates labels."""
        raw_input = self.entry.get()
        try:
            # Map user text input into float collections
            parsed_data = [float(x.strip()) for x in raw_input.split(",") if x.strip()]

            # Execute isolated backend computation
            stats = calculate_statistics(parsed_data)

            # Format UI telemetry response
            output = (
                f"Count:      {stats['count']}\n"
                f"Mean:       {stats['mean']}\n"
                f"Variance:   {stats['variance']}\n"
                f"Std Dev:    {stats['std_dev']}"
            )
            self.result_text.config(text=output)

        except ValueError:
            messagebox.showerror("Parsing Error",
                                 "Please input valid numeric values only!")
