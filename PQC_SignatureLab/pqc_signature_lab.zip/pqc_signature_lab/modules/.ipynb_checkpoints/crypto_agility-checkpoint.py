import oqs
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes


def sign(msg, alg):
    """
    Unified signature interface.
    Supported algorithms:
        - ecdsa
        - dilithium3
        - falcon512
    """
    if alg == "ecdsa":
        key = ec.generate_private_key(ec.SECP256R1())
        return key.sign(msg, ec.ECDSA(hashes.SHA256()))

    if alg == "dilithium3":
        with oqs.Signature("Dilithium3") as sig:
            sig.generate_keypair()
            return sig.sign(msg)

    if alg == "falcon512":
        with oqs.Signature("Falcon-512") as sig:
            sig.generate_keypair()
            return sig.sign(msg)

    raise ValueError(f"Unknown algorithm: {alg}")


def verify(msg, signature, alg):
    """
    Unified verification interface.
    """
    if alg == "ecdsa":
        key = ec.generate_private_key(ec.SECP256R1())
        pub = key.public_key()
        pub.verify(signature, msg, ec.ECDSA(hashes.SHA256()))
        return True

    if alg == "dilithium3":
        with oqs.Signature("Dilithium3") as sig:
            pk = sig.generate_keypair()
            return sig.verify(msg, signature, pk)

    if alg == "falcon512":
        with oqs.Signature("Falcon-512") as sig:
            pk = sig.generate_keypair()
            return sig.verify(msg, signature, pk)

    raise ValueError(f"Unknown algorithm: {alg}")