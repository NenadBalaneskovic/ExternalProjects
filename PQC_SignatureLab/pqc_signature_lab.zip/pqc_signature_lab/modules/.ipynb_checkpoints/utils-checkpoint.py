import time
import matplotlib.pyplot as plt

def timer(fn, *args, **kwargs):
    """
    Measure execution time of a function call.
    Returns (result, elapsed_time).
    """
    start = time.perf_counter()
    result = fn(*args, **kwargs)
    end = time.perf_counter()
    return result, end - start


def plot_bar(labels, values, title, path):
    """
    Create a bar chart and save it to a file.
    """
    plt.figure(figsize=(6,4))
    plt.bar(labels, values)
    plt.title(title)
    plt.ylabel("Value")
    plt.tight_layout()
    plt.savefig(path)
    plt.close()


def plot_line(labels, values, title, path):
    """
    Create a line chart and save it to a file.
    """
    plt.figure(figsize=(6,4))
    plt.plot(labels, values, marker='o')
    plt.title(title)
    plt.ylabel("Value")
    plt.tight_layout()
    plt.savefig(path)
    plt.close()